var APP_DATA = {
  "scenes": [
    {
      "id": "0-shower",
      "name": "shower",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        },
        {
          "tileSize": 512,
          "size": 2048
        }
      ],
      "faceSize": 1500,
      "initialViewParameters": {
        "pitch": 0,
        "yaw": 0,
        "fov": 1.5707963267948966
      },
      "linkHotspots": [
        {
          "yaw": 2.538961085533783,
          "pitch": 0.014103445176919749,
          "rotation": 0,
          "target": "3-hall"
        }
      ],
      "infoHotspots": []
    },
    {
      "id": "1-office",
      "name": "office",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        },
        {
          "tileSize": 512,
          "size": 2048
        }
      ],
      "faceSize": 1500,
      "initialViewParameters": {
        "yaw": -0.2884862286541132,
        "pitch": 0.003792584542907207,
        "fov": 1.3046490827601978
      },
      "linkHotspots": [
        {
          "yaw": -2.749871105094302,
          "pitch": -0.012578720882721939,
          "rotation": 0,
          "target": "2-living-room"
        }
      ],
      "infoHotspots": []
    },
    {
      "id": "2-living-room",
      "name": "living room",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        },
        {
          "tileSize": 512,
          "size": 2048
        }
      ],
      "faceSize": 1500,
      "initialViewParameters": {
        "pitch": 0,
        "yaw": 0,
        "fov": 1.5707963267948966
      },
      "linkHotspots": [
        {
          "yaw": 2.6932884296880797,
          "pitch": 0.06721633671794791,
          "rotation": 0,
          "target": "4-kitchen"
        }
      ],
      "infoHotspots": []
    },
    {
      "id": "3-hall",
      "name": "hall",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        },
        {
          "tileSize": 512,
          "size": 2048
        }
      ],
      "faceSize": 1500,
      "initialViewParameters": {
        "pitch": 0,
        "yaw": 0,
        "fov": 1.5707963267948966
      },
      "linkHotspots": [
        {
          "yaw": -0.43085800477542513,
          "pitch": -0.06246527332683982,
          "rotation": 0,
          "target": "0-shower"
        },
        {
          "yaw": 0.07314838296780657,
          "pitch": 0.04647394088542711,
          "rotation": 0,
          "target": "4-kitchen"
        }
      ],
      "infoHotspots": []
    },
    {
      "id": "4-kitchen",
      "name": "kitchen",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        },
        {
          "tileSize": 512,
          "size": 2048
        }
      ],
      "faceSize": 1500,
      "initialViewParameters": {
        "yaw": -0.28129056642146466,
        "pitch": -0.016419394619315852,
        "fov": 1.3046490827601978
      },
      "linkHotspots": [
        {
          "yaw": -0.9487167655207056,
          "pitch": -0.047611804577528005,
          "rotation": 0,
          "target": "0-shower"
        },
        {
          "yaw": -1.152621719451016,
          "pitch": 0.07122108804829352,
          "rotation": 0,
          "target": "3-hall"
        },
        {
          "yaw": 0.2541879040670203,
          "pitch": 0.09428551819635445,
          "rotation": 0,
          "target": "2-living-room"
        },
        {
          "yaw": -0.03994915092193985,
          "pitch": -0.013312050545524201,
          "rotation": 0,
          "target": "1-office"
        }
      ],
      "infoHotspots": []
    }
  ],
  "name": "interior test",
  "settings": {
    "mouseViewMode": "drag",
    "autorotateEnabled": true,
    "fullscreenButton": false,
    "viewControlButtons": false
  }
};
